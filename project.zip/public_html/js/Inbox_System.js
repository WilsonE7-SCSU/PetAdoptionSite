//Parts of the Inbox System

//The Inbox Menu

//How to display each message, each sorted vertically

//The  mouse-over/on-click event of each message

//Creating the server-side database/archive for each user that each verified user can access

//A small option menu in each displayed message that contains the delete message function, the reply function, and a way to forward messges to another user, each containing a form.


document.addEventListener('DOMContentLoaded', () => {
    const messageForm = document.getElementById('message-form');
    const messageInput = document.getElementById('message-input');
    const messageList = document.getElementById('message-list');

    //Amir's code
    const params = new URLSearchParams(window.location.search);
    const username = params.get("username");
    const userId = params.get("userId");
    const userType = params.get("userType");

    let messages = []; // Array to store messages (in-memory)

    // Function to render all messages
    function renderMessages() {
        messageList.innerHTML = ''; // Clear current list
        messages.forEach(message => {
            const messageElement = document.createElement('div');
            messageElement.classList.add('message');
            messageElement.innerHTML = `
                <strong>From: ${message.sender}</strong><br>
                <em>Pet: ${message.pet}</em>
                <p>${message.text}</p>
            `;
            messageList.appendChild(messageElement);
        });
        // Optional: auto-scroll to the latest message
        messageList.scrollTop = messageList.scrollHeight;
    }

    //Amir: inbox loader
    function loadInboxFromServer() {
        fetch(`/api/getInbox?username=${username}`)
            .then(res => res.json())
            .then(data => {
                messages = data.map(m => ({
                    text: m.msgText,
                    sender: m.senderName,
                    pet: m.petName,
                    senderId: m.senderId,
                    ownerId: m.ownerId,
                    petId: m.petId,
                    timestamp: new Date()
                }));
                renderMessages();
            });
    }
    //amir's code ends

    // Function to add a new message
    function addMessage(text, sender = 'You') {
        const newMessage = {
            id: Date.now(), // Simple unique ID
            text,
            sender,
            timestamp: new Date()
        };
        messages.push(newMessage);
        renderMessages(); // Re-render the list
    }

    // Handle form submission
    messageForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const messageText = messageInput.value.trim();
        if (!messageText) return;

        if (messages.length === 0) {
            alert("You cannot send a message until a shelter sends you one.");
            return;
        }

        const last = messages[messages.length - 1];

        let senderId = parseInt(userId);
        let recipientId;

        if (userType === "Pet Owner") {
            recipientId = last.senderId;
        } else {
            recipientId = last.ownerId;
        }

        const petId = last.petId;

        const body = new URLSearchParams();
        body.append("senderId", senderId);
        body.append("recipientId", recipientId);
        body.append("petId", petId);
        body.append("msgText", messageText);

        const res = await fetch("/api/sendReply", {
            method: "POST",
            body: body
        });

        const txt = await res.text();
        if (txt === "ok") {
            loadInboxFromServer();
            messageInput.value = "";
        } else {
            alert("Message failed to send.");
        }
    });

    loadInboxFromServer();
});

//Amir: REMOVING dummy messages, implementing actual messages using the database
//(im just going to comment them out)
    // Add some initial dummy messages
//    addMessage('Welcome to your inbox!', 'Admin');
//    addMessage('How are you today?', 'Friend');
//});
